# Calculadora 3D

Calculadora para precificação de produtos feitos em impressoras 3D (FDM e Resina).

## Project Type

Self-contained static HTML/CSS/JavaScript single-page application. All app logic
lives inside `index.html` (no build step required).

## Layout

- `index.html` — the calculator UI and all client-side logic.
- `IMPRESSORA 3D.png`, `favicon.svg`, `favicon-custom.svg` — static assets used
  by the page.
- `server.js` — minimal Node.js static file server used to serve the project on
  port 5000.
- `package.json` — declares `npm start` (runs `node server.js`).

## Local Development

The "Start application" workflow runs `node server.js` and binds to
`0.0.0.0:5000`. The Replit preview proxies that port; the server sets
`Cache-Control: no-store` so changes are picked up on refresh.

## Deployment

Configured for `autoscale` with run command `node server.js`. No build step.
